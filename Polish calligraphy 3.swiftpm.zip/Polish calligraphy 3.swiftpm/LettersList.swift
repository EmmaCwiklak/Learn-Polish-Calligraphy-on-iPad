import SwiftUI
import AVFoundation

struct LettersList: View {
    @State private var isNavigationActive = false

    
    var body: some View {
        NavigationSplitView {
            List(letters) { letter in
                NavigationLink {
                    PracticeLetterView(letter: letter)
                } label: {
                    LettersRow(letter: letter)
                }
            }
            .navigationTitle("All Letters")
        } detail: {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [Color.white, Color.red,Color.yellow, Color.blue]), startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
                VStack {
                    Image("Logo")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 250)
                        .padding(20)
                        .shadow(radius: 20)
                    
                    Text("Привіт! Learn the Polish Alphabet with me")
                        .bold()
                        .font(.title)
                        
                    
                    Spacer()
                    
                    Button(action: {
                        isNavigationActive = true
                    }) {
                        NavigationLink(
                            destination: PracticeLetterView(letter: letters[0]),
                            isActive: $isNavigationActive
                        ) {
                            Text("Start")
                                .padding()
                                .frame(width: 200)
                                .background(Color.red)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .bold()
                                .shadow(radius: 10)
                                .hoverEffect()
                        }}
                    
                    Spacer(minLength: 20)
                    
                    Text("Kaligrafia - Learn Polish Alphabet")
                        .foregroundColor(.white)
                        .font(.title2)
                        .padding(.bottom, 20)
                        .padding(.top, 20)
                }
            }
        }
    }
}
