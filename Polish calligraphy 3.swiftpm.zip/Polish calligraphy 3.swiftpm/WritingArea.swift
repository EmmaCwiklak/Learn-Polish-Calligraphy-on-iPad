import SwiftUI
import UIKit

struct Line{
    var points = [CGPoint]()
    var color: Color = .black
    var lineWidth: Double = 1.0
}

struct WritingArea: View{
    
    @Binding var lines: [Line]
    @State private var currentLine = Line()
    @State private var thickness: Double = 1.0
    @State private var appIsInDrawingMode = true
    
    var letter: LetterData

    var body: some View {
        
        ZStack{
            Image(letter.imageName)
                .resizable()
            
            Canvas { context, size in
                for line in lines {
                    var path = Path()
                    path.addLines(line.points)
                    context.stroke(path, with: .color(line.color), lineWidth: line.lineWidth)
                    self.lines = []
                }
                func scribbleInteraction(_ interaction: UIScribbleInteraction,
                                         shouldBeginAt location: CGPoint) -> Bool {
                    return !appIsInDrawingMode
                }
            }
            .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .local)
            .onChanged({ value in
                    let newPoint = value.location
                    currentLine.points.append(newPoint)
                    self.lines.append(currentLine)
                })
                .onEnded({ value in
                        self.currentLine = Line(points: [], color: .black, lineWidth: thickness)
                    })
            )
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        
        VStack {
            Text("Adjust Thickness:")

            Slider(value: $thickness, in: 1...7)
                .accentColor(.yellow)
                .padding(.horizontal)
                .padding(.vertical,3)
                .border(Color.black)
                .cornerRadius(4)
            
            Button("Try Again") {
                self.lines = []
            }
            .padding()
            .foregroundColor(.black)
            .font(.title3)
            .background(Color.white)
            .cornerRadius(10)
        }
    }
}
    

