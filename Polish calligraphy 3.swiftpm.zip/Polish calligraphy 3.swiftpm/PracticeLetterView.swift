import SwiftUI
import AVFoundation

struct PracticeLetterView: View {
    
    var letter: LetterData
    
    @State private var lines: [Line] = []
    @State private var thickness: Double = 0.0
    @State private var currentLetter: LetterData
    @State private var audioPlayer: AVAudioPlayer?
    
    init(letter: LetterData) {
        self.letter = letter
        self._currentLetter = State(initialValue: letter)
    }
    var body: some View {
        ZStack{
            
            VStack{
                HStack{
                    Text("""
                        Capital polish letter: \(letter.polishUppercaseLetter)
                        Small polish letter: \(letter.polishLowercaseLetter)
                        [\(letter.ukrainianUppercaseLetter), \(letter.ukrainianLowercaseLetter)]
                    """)
                    .font(.title)
                    .bold()
                    Spacer() 
                    Button(action: {
                        playSound() 
                    }) {
                        Image(systemName: "speaker.wave.2.fill")
                            .font(.system(size: 20))
                            .padding()
                            .background(Color.yellow)
                            .foregroundColor(.white)
                            .clipShape(Circle())
                    }
                }
                
                Text("An example word with this letter")
                VStack{
                    Text("""
                        \(letter.wordInPolish)
                        \(letter.wordInUkrainian)
                        """)
                    }
                
                Text("Practice below:")
                HStack{
                    VStack{
                        WritingArea(lines: $lines, letter: letter)
                    }.frame(maxWidth: 600)
                        .frame(maxHeight: 600)
                }
            }
            .padding()
        }
        .onAppear(){
            self.lines = []
        }
        .onChange(of: letter) { newLetter in
            self.currentLetter = newLetter
            self.lines = []
        }
    }
    
    func playSound() {
        if let soundURL = Bundle.main.url(forResource: letter.sound, withExtension: "m4a") {
            print("Sound URL: \(soundURL)")
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
                audioPlayer?.play()
                print("Sound played successfully")
            } catch {
                print("Error playing sound: \(error.localizedDescription)")
            }
        } else {
            print("Sound file not found")
        }
    }
}
