import SwiftUI

struct LettersRow: View{
    var letter: LetterData
    
    var body: some View{
        HStack{
            Text("\(letter.polishUppercaseLetter), \(letter.polishLowercaseLetter) ")
            Spacer()
            Text(" \(letter.ukrainianUppercaseLetter), \(letter.ukrainianLowercaseLetter)")
        }
        
    }
}

