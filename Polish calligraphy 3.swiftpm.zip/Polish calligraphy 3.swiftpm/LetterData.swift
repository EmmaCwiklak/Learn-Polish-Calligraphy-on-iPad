import SwiftUI
import AVFAudio

struct LetterData: Codable, Identifiable, Equatable{
    var id: Int
    var ukrainianUppercaseLetter: String
    var ukrainianLowercaseLetter: String
    var polishUppercaseLetter: String
    var polishLowercaseLetter: String
    var wordInPolish: String
    var wordInUkrainian: String
    var description: String
    var imageName: String
    var image: Image {
        Image(imageName)
    }
    
    var sound: String
}
